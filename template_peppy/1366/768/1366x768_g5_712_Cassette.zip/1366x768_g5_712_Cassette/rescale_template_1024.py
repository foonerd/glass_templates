#!/usr/bin/env python3
"""
PeppyMeter Template Rescaler
Rescales template artwork and meters.txt values to target resolution.
Uses best-fit scaling with centering for mismatched aspect ratios.
"""

import os
import sys
import shutil
from pathlib import Path
from PIL import Image

# =============================================================================
# CONFIGURATION
# =============================================================================

SOURCE_WIDTH = 1920
SOURCE_HEIGHT = 1080
TARGET_WIDTH = 1280
TARGET_HEIGHT = 720

INPUT_FOLDER = "1920x1080_g5_709_meters"
OUTPUT_FOLDER = "1280x720_g5_709_meters"

IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg'}

# =============================================================================
# PARAMETER CLASSIFICATION
# =============================================================================

# Position keys: x,y coordinates on screen - apply scale AND offset
POSITION_KEYS = {
    # Circular meter origins
    'left.origin.x', 'left.origin.y',
    'right.origin.x', 'right.origin.y',
    # Linear meter positions
    'left.x', 'left.y',
    'right.x', 'right.y',
    # General meter position
    'meter.x', 'meter.y',
    # Album art
    'albumart.pos',
    # Vinyl/turntable
    'vinyl.pos', 'vinyl.center',
    'tonearm.pivot.screen',
    # Reel-to-reel
    'reel.left.pos', 'reel.left.center',
    'reel.right.pos', 'reel.right.center',
    # UI elements
    'progress.pos',
    'volume.pos',
    'mute.pos',
    'playstate.pos',
    'repeat.pos',
    'shuffle.pos',
    'time.remaining.pos',
    # Play info text positions
    'playinfo.title.pos',
    'playinfo.artist.pos',
    'playinfo.album.pos',
    'playinfo.type.pos',
    'playinfo.samplerate.pos',
}

# Dimension keys: sizes/distances - apply scale only, no offset
DIMENSION_KEYS = {
    # Circular meter
    'distance',
    # Linear meter
    'position.regular', 'position.overload',
    'step.width.regular', 'step.width.overload',
    # Album art
    'albumart.dimension',
    # UI elements
    'progress.dim',
    'volume.dim',
    'playinfo.type.dimension',
    # Max widths
    'playinfo.title.maxwidth',
    'playinfo.artist.maxwidth',
    'playinfo.album.maxwidth',
    'playinfo.samplerate.maxwidth',
    # Volume slider
    'volume.slider.travel',
    'volume.slider.tip.offset',
    # Tonearm (image-relative)
    'tonearm.pivot.image',
}

# Font size keys: apply scale only
FONT_SIZE_KEYS = {
    'font.size.digi',
    'font.size.light',
    'font.size.regular',
    'font.size.bold',
}

# =============================================================================
# SCALING CALCULATOR
# =============================================================================

def calculate_scaling():
    """Calculate scale factor and centering offsets for best fit."""
    scale_x = TARGET_WIDTH / SOURCE_WIDTH
    scale_y = TARGET_HEIGHT / SOURCE_HEIGHT
    scale = min(scale_x, scale_y)
    
    scaled_w = int(SOURCE_WIDTH * scale)
    scaled_h = int(SOURCE_HEIGHT * scale)
    
    offset_x = (TARGET_WIDTH - scaled_w) // 2
    offset_y = (TARGET_HEIGHT - scaled_h) // 2
    
    return scale, offset_x, offset_y

# =============================================================================
# VALUE TRANSFORMERS
# =============================================================================

def scale_position_value(value_str, scale, offset_x, offset_y):
    """
    Scale position values (x,y or x,y,style).
    Returns scaled string with same format.
    """
    parts = value_str.split(',')
    result = []
    
    for i, part in enumerate(parts):
        part = part.strip()
        try:
            num = float(part)
            if i == 0:  # x coordinate
                scaled = int(round(num * scale)) + offset_x
            elif i == 1:  # y coordinate
                scaled = int(round(num * scale)) + offset_y
            else:
                # Third+ parts might be numeric or style names
                try:
                    scaled = int(round(num * scale))
                except:
                    result.append(part)
                    continue
            result.append(str(scaled))
        except ValueError:
            # Non-numeric (e.g., "bold", "regular")
            result.append(part)
    
    return ','.join(result)

def scale_dimension_value(value_str, scale):
    """
    Scale dimension values (w,h or single values or offsets).
    Returns scaled string with same format.
    """
    parts = value_str.split(',')
    result = []
    
    for part in parts:
        part = part.strip()
        try:
            num = float(part)
            scaled = int(round(num * scale))
            result.append(str(scaled))
        except ValueError:
            # Non-numeric, keep as-is
            result.append(part)
    
    return ','.join(result)

def scale_font_size(value_str, scale):
    """Scale font size value."""
    try:
        num = float(value_str.strip())
        return str(int(round(num * scale)))
    except ValueError:
        return value_str

# =============================================================================
# METERS.TXT PARSER AND TRANSFORMER
# =============================================================================

def process_meters_txt(input_path, output_path, scale, offset_x, offset_y):
    """Parse and transform meters.txt with scaled values."""
    
    with open(input_path, 'r') as f:
        lines = f.readlines()
    
    output_lines = []
    warnings = []
    
    for line_num, line in enumerate(lines, 1):
        original = line.rstrip('\n\r')
        
        # Preserve blank lines
        if not original.strip():
            output_lines.append(original)
            continue
        
        # Preserve comments
        if original.strip().startswith('#'):
            output_lines.append(original)
            continue
        
        # Preserve section headers
        if original.strip().startswith('[') and original.strip().endswith(']'):
            output_lines.append(original)
            continue
        
        # Parse key = value
        if '=' not in original:
            output_lines.append(original)
            continue
        
        eq_pos = original.index('=')
        key_part = original[:eq_pos].strip()
        value_part = original[eq_pos + 1:].strip()
        
        # Preserve leading whitespace/indentation
        leading = ''
        for ch in original:
            if ch in ' \t':
                leading += ch
            else:
                break
        
        # Determine transformation
        new_value = value_part
        
        if key_part in POSITION_KEYS:
            if value_part:  # Not empty
                new_value = scale_position_value(value_part, scale, offset_x, offset_y)
        elif key_part in DIMENSION_KEYS:
            if value_part:  # Not empty
                new_value = scale_dimension_value(value_part, scale)
        elif key_part in FONT_SIZE_KEYS:
            if value_part:  # Not empty
                new_value = scale_font_size(value_part, scale)
        # else: keep original value (angles, colors, booleans, etc.)
        
        # Reconstruct line
        new_line = f"{key_part} = {new_value}"
        output_lines.append(new_line)
    
    # Write output
    with open(output_path, 'w') as f:
        for line in output_lines:
            f.write(line + '\n')
    
    return warnings

# =============================================================================
# IMAGE SCALER
# =============================================================================

def scale_images(input_folder, output_folder, scale):
    """Scale all images in folder and subfolders."""
    
    input_path = Path(input_folder)
    output_path = Path(output_folder)
    
    processed = []
    errors = []
    
    for root, dirs, files in os.walk(input_path):
        # Calculate relative path
        rel_root = Path(root).relative_to(input_path)
        target_dir = output_path / rel_root
        
        # Create target directory
        target_dir.mkdir(parents=True, exist_ok=True)
        
        for filename in files:
            src_file = Path(root) / filename
            dst_file = target_dir / filename
            ext = src_file.suffix.lower()
            
            if ext in IMAGE_EXTENSIONS:
                try:
                    with Image.open(src_file) as img:
                        orig_w, orig_h = img.size
                        new_w = int(round(orig_w * scale))
                        new_h = int(round(orig_h * scale))
                        
                        # Ensure minimum dimension of 1
                        new_w = max(1, new_w)
                        new_h = max(1, new_h)
                        
                        resized = img.resize((new_w, new_h), Image.LANCZOS)
                        
                        # Preserve format
                        if ext == '.jpg' or ext == '.jpeg':
                            resized.save(dst_file, 'JPEG', quality=95)
                        else:
                            resized.save(dst_file, 'PNG')
                        
                        processed.append(f"{rel_root / filename}: {orig_w}x{orig_h} -> {new_w}x{new_h}")
                
                except Exception as e:
                    errors.append(f"{rel_root / filename}: {str(e)}")
    
    return processed, errors

# =============================================================================
# MAIN
# =============================================================================

def main():
    print("PeppyMeter Template Rescaler")
    print("=" * 50)
    print(f"Source: {SOURCE_WIDTH}x{SOURCE_HEIGHT}")
    print(f"Target: {TARGET_WIDTH}x{TARGET_HEIGHT}")
    print(f"Input:  {INPUT_FOLDER}")
    print(f"Output: {OUTPUT_FOLDER}")
    print()
    
    # Validate input
    if not os.path.isdir(INPUT_FOLDER):
        print(f"ERROR: Input folder not found: {INPUT_FOLDER}")
        sys.exit(1)
    
    meters_input = os.path.join(INPUT_FOLDER, 'meters.txt')
    if not os.path.isfile(meters_input):
        print(f"ERROR: meters.txt not found in {INPUT_FOLDER}")
        sys.exit(1)
    
    # Calculate scaling
    scale, offset_x, offset_y = calculate_scaling()
    print(f"Scale factor: {scale:.6f}")
    print(f"Centering offset: x={offset_x}, y={offset_y}")
    print()
    
    # Create output folder
    if os.path.exists(OUTPUT_FOLDER):
        shutil.rmtree(OUTPUT_FOLDER)
    os.makedirs(OUTPUT_FOLDER)
    
    # Process meters.txt
    print("Processing meters.txt...")
    meters_output = os.path.join(OUTPUT_FOLDER, 'meters.txt')
    warnings = process_meters_txt(meters_input, meters_output, scale, offset_x, offset_y)
    if warnings:
        for w in warnings:
            print(f"  WARNING: {w}")
    print("  Done.")
    print()
    
    # Process images
    print("Scaling images...")
    processed, errors = scale_images(INPUT_FOLDER, OUTPUT_FOLDER, scale)
    for p in processed:
        print(f"  {p}")
    if errors:
        print()
        print("Errors:")
        for e in errors:
            print(f"  ERROR: {e}")
    print()
    
    print("=" * 50)
    print(f"Complete. Output folder: {OUTPUT_FOLDER}")
    print(f"Images processed: {len(processed)}")
    if errors:
        print(f"Errors: {len(errors)}")

if __name__ == '__main__':
    main()
